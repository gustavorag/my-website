import React, { Component } from 'react';

class App1 extends Component {
  render() {
    return (
      <h1>This is the App1</h1>
    );
  }
}

export default App1;
