import React, { Component } from 'react';

class App2 extends Component {
  render() {
    return (
      <h1>This is the App2</h1>
    );
  }
}

export default App2;
