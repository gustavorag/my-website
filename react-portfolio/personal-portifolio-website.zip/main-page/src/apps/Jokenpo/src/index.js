import React from 'react';
import ReactDOM from 'react-dom';
import JokenPoGame from './JokenPoGame';
import './index.css';

ReactDOM.render(
  <JokenPoGame />,
  document.getElementById('root')
);
