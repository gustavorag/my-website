import React from 'react';

export default (props) => (
  <h2>About</h2>
)
