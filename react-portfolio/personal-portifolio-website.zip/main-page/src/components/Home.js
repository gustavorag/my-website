import React from 'react';

export default (props) => (
  <h2>Home</h2>
)
