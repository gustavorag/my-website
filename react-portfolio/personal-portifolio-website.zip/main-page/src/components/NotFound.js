import React from 'react';

export default (props) => (
  <h2>Not Found</h2>
)
